export default function PageNotFound() {
  return (<h1>Erro 404</h1>);
}
