export default function Filmes() {
  console.log(data);
  return (
    <>
      <h1>Filmes</h1>
    </>
  );
}
