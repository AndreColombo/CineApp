export default function Sobre() {
  return (<h1>Sobre</h1>);
}
